Put Schedule Planner.html in this folder and run schedule_pinner.exe
Then enjoy your ics file :)